CLIPPER_LABEL = {
    "layer_id": 'layer_id',
    "geoserver_url": 'geoserver_url'
}
